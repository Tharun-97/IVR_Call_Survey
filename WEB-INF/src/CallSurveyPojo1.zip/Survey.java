public class Survey {
	private BookingDetails bookingDetails;
	private Question_Option select;
	private Response response;

	public BookingDetails getBookingDetails() {
		return bookingDetails;
	}

	public void setBookingDetails(BookingDetails bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

	public Question_Option getSelect() {
		return select;
	}

	public void setSelect(Question_Option select) {
		this.select = select;
	}

	public Response getResponse() {
		return response;
	}

	public void setResponse(Response response) {
		this.response = response;
	}

}
