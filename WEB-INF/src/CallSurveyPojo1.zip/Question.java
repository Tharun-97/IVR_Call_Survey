import java.util.Set;

public class Question {
	private int question_id;
	private String question;
	private Set<Question_Option> question_option;

	public int getQuestion_id() {
		return question_id;
	}

	public void setQuestion_id(int question_id) {
		this.question_id = question_id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public Set<Question_Option> getQuestion_option() {
		return question_option;
	}

	public void setQuestion_option(Set<Question_Option> question_option) {
		this.question_option = question_option;
	}

}
