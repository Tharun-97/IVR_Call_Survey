

public class Survey {
	private BookingDetails bookingDetails;

	private Response response;
}
