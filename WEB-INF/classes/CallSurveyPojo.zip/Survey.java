import java.util.Set;

public class Survey {
	private BookingDetails booking_id;
	private Set<Question> questions;
	private Response response;

	private void addquestion(Question question) {
		questions.add(question);
	}

	public Survey(BookingDetails booking_id, Set<Question> questions, Response response) {
		this.booking_id = booking_id;
		this.questions = questions;
		this.response = response;
	}

	public BookingDetails getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(BookingDetails booking_id) {
		this.booking_id = booking_id;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public Response getResponse() {
		return response;
	}

	public void setResponse(Response response) {
		this.response = response;
	}

}
