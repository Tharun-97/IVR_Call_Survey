
public class Response {
	private int id;
	private String response;
	private Question question_id;

	public Response(int id, String response, Question question_id) {
		this.id = id;
		this.response = response;
		this.question_id = question_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Question getQuestion_id() {
		return question_id;
	}

	public void setQuestion_id(Question question_id) {
		this.question_id = question_id;
	}

}
