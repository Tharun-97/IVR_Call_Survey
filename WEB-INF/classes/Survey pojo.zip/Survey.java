import java.util.Set;

public class Survey {
	private BookingDetails booking_id;
	private Set<Question> questions;
	private String response;

	public Survey(BookingDetails booking_id, Set<Question> questions, String response) {
		this.booking_id = booking_id;
		this.questions = questions;
		this.response = response;
	}

	public Survey() {

	}

	public BookingDetails getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(BookingDetails booking_id) {
		this.booking_id = booking_id;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

}
